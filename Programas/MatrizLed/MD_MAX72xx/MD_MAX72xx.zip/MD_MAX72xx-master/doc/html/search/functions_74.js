var searchData=
[
  ['transform',['transform',['../class_m_d___m_a_x72_x_x.html#aa81af9a9e4309d9971bec7da3eef5890',1,'MD_MAX72XX::transform(transformType_t ttype)'],['../class_m_d___m_a_x72_x_x.html#a67f8567afe489f497f75448a3137a1ef',1,'MD_MAX72XX::transform(uint8_t buf, transformType_t ttype)']]]
];
